<div class="page-header px-4">
  <h1>{!! App::title() !!}</h1>
</div>
