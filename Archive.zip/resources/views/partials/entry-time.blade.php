<a href="{{ get_permalink() }}">
  <time class="updated text-gray-500 text-sm uppercase" datetime="{{ get_post_time('c', true) }}">{{ get_the_date() }}</time>
</a>
