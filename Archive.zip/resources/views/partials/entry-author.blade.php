<p class="byline author vcard">
  <a href="{{ get_author_posts_url(get_the_author_meta('ID')) }}" rel="author" class="fn flex">
    {!! User::avatar() !!}<span class="self-center px-2 font-semibold text-sm">{{ get_the_author() }}</span>
  </a>
</p>
